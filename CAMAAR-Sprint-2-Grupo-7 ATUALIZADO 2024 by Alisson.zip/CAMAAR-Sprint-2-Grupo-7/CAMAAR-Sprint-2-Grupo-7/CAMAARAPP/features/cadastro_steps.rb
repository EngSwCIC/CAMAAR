Given("I am on "Cadastro" page") do
    visit 'http://localhost:3000/users/sign_up/1'
    expect(@driver.title).to eq('Cadastro')
end

When("I fill in my password and click the button") do
    fill_in "password", with: "teste2"
    driver.findelement (by.class.name("button")).click();
end

When("I click the "Login" button") do
    expect(User.find(1).nome).to eq(Aluno.find(1).nome)
end