Given("I am on the user_home page") do
    driver.findelement (by.class.name("button")).click();
end