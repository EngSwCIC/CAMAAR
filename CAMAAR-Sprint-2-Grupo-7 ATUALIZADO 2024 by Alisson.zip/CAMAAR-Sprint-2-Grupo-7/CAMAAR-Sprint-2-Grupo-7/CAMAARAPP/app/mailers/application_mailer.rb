class ApplicationMailer < ActionMailer::Base
  default from: "dacam33c@gmail.com"
  layout "mailer"
end
