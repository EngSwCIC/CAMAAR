<h1> <%= @user.name %></h1>
