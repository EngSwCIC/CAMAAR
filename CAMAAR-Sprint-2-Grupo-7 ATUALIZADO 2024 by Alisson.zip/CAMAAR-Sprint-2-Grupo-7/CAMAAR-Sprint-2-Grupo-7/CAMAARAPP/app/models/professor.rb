class Professor < ApplicationRecord
end
