require "test_helper"

class AlunoMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
