# Preview all emails at http://localhost:3000/rails/mailers/aluno_mailer
class AlunoMailerPreview < ActionMailer::Preview

end
